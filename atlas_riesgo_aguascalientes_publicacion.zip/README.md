# Atlas de Riesgo del Estado de Aguascalientes

Visor cartográfico interactivo desarrollado en R Shiny.

## Estructura

- `app.R`: aplicación Shiny.
- `datos/`: capas espaciales utilizadas por la aplicación.
- `manifest.json`: dependencias de R para el despliegue.

## Publicación

El contenido está preparado para publicarse como una aplicación Shiny en Posit Connect Cloud.

La carpeta `datos/` debe mantenerse junto a `app.R`. No mover ni renombrar los archivos espaciales que utiliza `app.R`.

## Nota sobre `manifest.json`

El archivo incluido funciona como manifiesto de proyecto para el despliegue. Si Posit Connect Cloud solicita regenerarlo desde el entorno de publicación, conviene usar el manifiesto generado por `rsconnect`/Positron/RStudio en el mismo entorno donde se publique para fijar las versiones exactas de R y de los paquetes.
