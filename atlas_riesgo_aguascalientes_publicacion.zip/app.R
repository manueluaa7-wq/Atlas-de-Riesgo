# ============================================================
# ATLAS DE RIESGO DEL ESTADO DE AGUASCALIENTES
# VISOR CARTOGRÁFICO INTERACTIVO
#
# VERSIÓN 5.3
# OPTIMIZADA PARA POSIT CONNECT CLOUD
#
# ============================================================
# CARACTERÍSTICAS
# ============================================================
#
# - Mapa topográfico
# - Mapa satelital
# - Mapa de calles
# - 7 capas de Peligros
# - 1 capa de Vulnerabilidad
# - Leyenda dinámica
# - Consulta de atributos
# - Búsqueda de atributos
# - Medición mediante Leaflet
# - Pantalla completa real
# - Control de opacidad
# - Interfaz moderna gris / azul
# - Diseño responsive
# - Manejo robusto de errores
# - Carga espacial optimizada
# - Compatible con Posit Connect Cloud
#
# ============================================================


# ============================================================
# 1. LIBRERÍAS
# ============================================================

library(shiny)
library(leaflet)
library(sf)
library(dplyr)
library(htmltools)


# ============================================================
# 2. CONFIGURACIÓN GENERAL
# ============================================================

options(
  shiny.maxRequestSize = 100 * 1024^2
)

Insumos <- file.path(getwd(), "datos")

CRS_MAPA <- 4326

CENTRO_LNG <- -102.296
CENTRO_LAT <- 21.885
ZOOM_INICIAL <- 9


# ============================================================
# 3. MENSAJE DE INICIO
# ============================================================

cat("\n")
cat("============================================================\n")
cat(" ATLAS DE RIESGO DE AGUASCALIENTES\n")
cat(" VERSIÓN 5.3\n")
cat(" OPTIMIZADA PARA POSIT CONNECT CLOUD\n")
cat("============================================================\n\n")


# ============================================================
# 4. VALIDACIÓN DEL DIRECTORIO DE DATOS
# ============================================================

if (!dir.exists(Insumos)) {
  
  stop(
    paste0(
      "\n============================================================\n",
      " ERROR DE CONFIGURACIÓN\n",
      "============================================================\n\n",
      "No se encontró la carpeta '",
      Insumos,
      "'.\n\n",
      "Directorio actual:\n",
      getwd(),
      "\n\n",
      "La carpeta 'datos' debe estar al mismo nivel que app.R.\n"
    )
  )
  
}


# ============================================================
# 5. VALIDACIÓN DE ARCHIVOS ESPACIALES REQUERIDOS
# ============================================================

archivos_requeridos <- c(
  "2019 ZM.shp",
  "2020 ZM.shp",
  "2021 ZM.shp",
  "2022 ZM.shp",
  "2023 ZM.shp",
  "ZM Sequia.shp",
  "ZM Inundabilidad.shp",
  "Densidad_Pob_ZMAGS.shp"
)

faltantes <- archivos_requeridos[
  !file.exists(file.path(Insumos, archivos_requeridos))
]

if (length(faltantes) > 0) {
  warning(
    paste0(
      "Faltan archivos SHP requeridos en 'datos': ",
      paste(faltantes, collapse = ", ")
    )
  )
}


# ============================================================
# 5. FUNCIÓN ROBUSTA PARA CARGAR CAPAS
# ============================================================

cargar_capa <- function(archivo) {
  
  ruta <- file.path(
    Insumos,
    archivo
  )
  
  if (!file.exists(ruta)) {
    
    warning(
      paste0(
        "No se encontró la capa: ",
        ruta
      )
    )
    
    return(NULL)
    
  }
  
  cat(
    "Cargando capa:",
    archivo,
    "...\n"
  )
  
  resultado <- tryCatch({
    
    capa <- st_read(
      ruta,
      quiet = TRUE,
      stringsAsFactors = FALSE
    )
    
    if (nrow(capa) == 0) {
      
      warning(
        paste0(
          "La capa ",
          archivo,
          " no contiene elementos."
        )
      )
      
      return(capa)
      
    }
    
    # ----------------------------------------------------------
    # CRS
    # ----------------------------------------------------------
    
    if (is.na(st_crs(capa))) {
      
      warning(
        paste0(
          "La capa ",
          archivo,
          " no tiene CRS definido."
        )
      )
      
    } else {
      
      capa <- st_transform(
        capa,
        CRS_MAPA
      )
      
    }
    
    
    # ----------------------------------------------------------
    # VALIDACIÓN GEOMÉTRICA CONDICIONAL
    #
    # Solo se ejecuta si existen geometrías inválidas.
    # Esto evita realizar st_make_valid() innecesariamente.
    # ----------------------------------------------------------
    
    geometria_valida <- tryCatch(
      
      all(
        st_is_valid(
          capa,
          NA_on_exception = TRUE
        )
      ),
      
      error = function(e) TRUE
      
    )
    
    if (!geometria_valida) {
      
      cat(
        "  -> Corrigiendo geometrías inválidas...\n"
      )
      
      capa <- tryCatch(
        
        st_make_valid(capa),
        
        error = function(e) {
          
          warning(
            paste0(
              "No fue posible corregir todas las geometrías de ",
              archivo,
              ": ",
              conditionMessage(e)
            )
          )
          
          capa
          
        }
        
      )
      
    }
    
    
    # ----------------------------------------------------------
    # LIMPIAR GEOMETRÍAS VACÍAS
    # ----------------------------------------------------------
    
    capa <- capa[
      !st_is_empty(capa),
      ,
      drop = FALSE
    ]
    
    
    # ----------------------------------------------------------
    # RESULTADO
    # ----------------------------------------------------------
    
    capa
    
  },
  
  error = function(e) {
    
    warning(
      paste0(
        "Error al cargar ",
        archivo,
        ": ",
        conditionMessage(e)
      )
    )
    
    NULL
    
  })
  
  return(resultado)
  
}


# ============================================================
# 6. CARGA DE CAPAS
# ============================================================

incendios_2019 <- cargar_capa(
  "2019 ZM.shp"
)

incendios_2020 <- cargar_capa(
  "2020 ZM.shp"
)

incendios_2021 <- cargar_capa(
  "2021 ZM.shp"
)

incendios_2022 <- cargar_capa(
  "2022 ZM.shp"
)

incendios_2023 <- cargar_capa(
  "2023 ZM.shp"
)

sequia <- cargar_capa(
  "ZM Sequia.shp"
)

inundacion <- cargar_capa(
  "ZM Inundabilidad.shp"
)

densidad <- cargar_capa(
  "Densidad_Pob_ZMAGS.shp"
)


# ============================================================
# 7. CONFIGURACIÓN DE CAPAS
# ============================================================

capas <- list(
  
  incendios_2019 = list(
    datos = incendios_2019,
    nombre = "Incendios 2019",
    categoria = "Peligros",
    color = "#E53935",
    borde = "#8B0000"
  ),
  
  incendios_2020 = list(
    datos = incendios_2020,
    nombre = "Incendios 2020",
    categoria = "Peligros",
    color = "#F4511E",
    borde = "#8B0000"
  ),
  
  incendios_2021 = list(
    datos = incendios_2021,
    nombre = "Incendios 2021",
    categoria = "Peligros",
    color = "#FB8C00",
    borde = "#8B0000"
  ),
  
  incendios_2022 = list(
    datos = incendios_2022,
    nombre = "Incendios 2022",
    categoria = "Peligros",
    color = "#FFC107",
    borde = "#8B0000"
  ),
  
  incendios_2023 = list(
    datos = incendios_2023,
    nombre = "Incendios 2023",
    categoria = "Peligros",
    color = "#E53935",
    borde = "#8B0000"
  ),
  
  inundacion = list(
    datos = inundacion,
    nombre = "Inundabilidad",
    categoria = "Peligros",
    color = "#2196F3",
    borde = "#0D47A1"
  ),
  
  sequia = list(
    datos = sequia,
    nombre = "Sequía",
    categoria = "Peligros",
    color = "#FDD835",
    borde = "#8D6E00"
  ),
  
  densidad = list(
    datos = densidad,
    nombre = "Densidad de población",
    categoria = "Vulnerabilidad",
    color = "#8E44AD",
    borde = "#4A235A"
  )
  
)


# ============================================================
# 8. VERIFICACIÓN DE CAPAS
# ============================================================

cat("\n")
cat("============================================================\n")
cat(" VERIFICACIÓN DE CAPAS\n")
cat("============================================================\n")

for (id in names(capas)) {
  
  datos <- capas[[id]]$datos
  
  if (is.null(datos)) {
    
    cat(
      "✗",
      capas[[id]]$nombre,
      ": NO DISPONIBLE\n"
    )
    
  } else {
    
    cat(
      "✓",
      capas[[id]]$nombre,
      ":",
      nrow(datos),
      "elementos\n"
    )
    
  }
  
}

cat("\n")


# ============================================================
# 9. FUNCIÓN PARA OBTENER CAPAS SELECCIONADAS
# ============================================================

obtener_capas_seleccionadas <- function(input) {
  
  seleccionadas <- input$capas
  
  if (is.null(seleccionadas)) {
    
    seleccionadas <- character(0)
    
  }
  
  if (isTRUE(input$densidad)) {
    
    seleccionadas <- c(
      seleccionadas,
      "densidad"
    )
    
  }
  
  seleccionadas <- unique(
    seleccionadas
  )
  
  seleccionadas[
    seleccionadas %in% names(capas)
  ]
  
}


# ============================================================
# 10. FUNCIÓN PARA CREAR TABLA DE ATRIBUTOS
# ============================================================

crear_tabla_atributos <- function(datos) {
  
  if (is.null(datos) || nrow(datos) == 0) {
    
    return(
      "<p>No existen atributos disponibles.</p>"
    )
    
  }
  
  columna_geometria <- attr(
    datos,
    "sf_column"
  )
  
  columnas <- names(datos)
  
  columnas <- columnas[
    columnas != columna_geometria
  ]
  
  if (length(columnas) == 0) {
    
    return(
      "<p>No existen atributos disponibles.</p>"
    )
    
  }
  
  filas <- lapply(
    
    columnas,
    
    function(campo) {
      
      valor <- datos[[campo]][1]
      
      if (
        length(valor) == 0 ||
        is.na(valor)
      ) {
        
        valor <- "Sin información"
        
      }
      
      valor <- as.character(valor)
      
      if (nchar(valor) > 500) {
        
        valor <- paste0(
          substr(valor, 1, 500),
          "..."
        )
        
      }
      
      paste0(
        
        "<tr>",
        
        "<td class='campo-atributo'>",
        htmlEscape(campo),
        "</td>",
        
        "<td>",
        htmlEscape(valor),
        "</td>",
        
        "</tr>"
        
      )
      
    }
    
  )
  
  paste0(
    
    "<table class='tabla-atributos'>",
    
    paste(
      unlist(filas),
      collapse = ""
    ),
    
    "</table>"
    
  )
  
}


# ============================================================
# 11. INTERFAZ
# ============================================================

ui <- fluidPage(
  
  tags$head(
    
    tags$meta(
      name = "viewport",
      content = "width=device-width, initial-scale=1"
    ),
    
    # ========================================================
    # JAVASCRIPT
    # ========================================================
    
    tags$script(
      HTML("
      // =====================================================
      // PANTALLA COMPLETA
      // =====================================================

      Shiny.addCustomMessageHandler(
        'activar_pantalla_completa',
        function(message) {

          var elemento = document.documentElement;

          if (!document.fullscreenElement) {

            if (elemento.requestFullscreen) {

              elemento.requestFullscreen();

            } else if (elemento.webkitRequestFullscreen) {

              elemento.webkitRequestFullscreen();

            } else if (elemento.msRequestFullscreen) {

              elemento.msRequestFullscreen();

            }

          } else {

            if (document.exitFullscreen) {

              document.exitFullscreen();

            }

          }

        }
      );


      // =====================================================
      // OPACIDAD DE CAPAS
      // =====================================================

      Shiny.addCustomMessageHandler(
        'actualizar_opacidad',
        function(message) {

          var opacidad = parseFloat(message.valor);

          if (isNaN(opacidad)) {

            return;

          }

          var paths = document.querySelectorAll(
            '#mapa .leaflet-overlay-pane svg path'
          );

          paths.forEach(function(path) {

            path.style.fillOpacity = opacidad;
            path.style.opacity = opacidad;

          });

        }
      );


      // =====================================================
      // REDIMENSIONAMIENTO DEL MAPA
      // =====================================================

      $(document).on(
        'shiny:value',
        function(event) {

          if (event.target &&
              event.target.id === 'mapa') {

            setTimeout(
              function() {

                window.dispatchEvent(
                  new Event('resize')
                );

              },
              150
            );

          }

        }
      );

      ")
    ),
    
    # ========================================================
    # CSS
    # ========================================================
    
    tags$style(
      
      HTML("

      /* =====================================================
         GENERAL
         ===================================================== */

      * {
        box-sizing: border-box;
      }

      html,
      body {
        margin: 0;
        padding: 0;
        width: 100%;
        height: 100%;
        overflow: hidden;
        font-family:
          'Segoe UI',
          Arial,
          sans-serif;
        background: #eef2f6;
      }


      /* =====================================================
         ENCABEZADO
         ===================================================== */

      .encabezado {

        position: fixed;

        top: 0;
        left: 0;
        right: 0;

        height: 76px;

        background:
          linear-gradient(
            135deg,
            #17324d 0%,
            #24577d 55%,
            #2f6f98 100%
          );

        color: #ffffff;

        padding:
          12px 24px;

        z-index: 2000;

        box-shadow:
          0 2px 12px
          rgba(20,42,62,.28);

        border-bottom:
          1px solid
          rgba(255,255,255,.18);

      }


      .titulo {

        font-size: 23px;

        line-height: 1.2;

        font-weight: 700;

        letter-spacing: .2px;

        margin: 0;

      }


      .subtitulo {

        font-size: 12px;

        color: #dbe9f3;

        margin-top: 5px;

      }


      .badge-atlas {

        position: absolute;

        right: 24px;

        top: 21px;

        padding:
          7px 13px;

        border-radius: 20px;

        background:
          rgba(255,255,255,.13);

        border:
          1px solid
          rgba(255,255,255,.22);

        font-size: 11px;

        font-weight: 600;

        letter-spacing: .5px;

      }


      /* =====================================================
         MAPA
         ===================================================== */

      #mapa {

        position: fixed !important;

        top: 76px !important;

        left: 0 !important;

        right: 0 !important;

        bottom: 0 !important;

        width: 100% !important;

        height:
          calc(100vh - 76px) !important;

        z-index: 1;

      }


      /* =====================================================
         PANELES
         ===================================================== */

      .panel-izquierdo,
      .panel-derecho {

        position: fixed;

        top: 91px;

        max-height:
          calc(100vh - 106px);

        overflow-y: auto;

        background:
          rgba(255,255,255,.97);

        border:
          1px solid #d9e2ea;

        border-radius: 12px;

        box-shadow:
          0 8px 28px
          rgba(31,55,75,.20);

        padding: 16px;

        z-index: 1500;

        backdrop-filter:
          blur(8px);

      }


      .panel-izquierdo {

        left: 15px;

        width: 350px;

      }


      .panel-derecho {

        right: 15px;

        width: 340px;

      }


      .panel-izquierdo::-webkit-scrollbar,
      .panel-derecho::-webkit-scrollbar {

        width: 6px;

      }


      .panel-izquierdo::-webkit-scrollbar-thumb,
      .panel-derecho::-webkit-scrollbar-thumb {

        background: #b9c9d6;

        border-radius: 10px;

      }


      /* =====================================================
         TÍTULOS
         ===================================================== */

      .titulo-panel {

        font-size: 14px;

        font-weight: 700;

        color: #17324d;

        padding:
          9px 0 10px;

        margin:
          0 0 12px;

        border-bottom:
          2px solid #2f6f98;

        letter-spacing: .4px;

      }


      .titulo-panel i {

        margin-right: 7px;

        color: #2f6f98;

      }


      /* =====================================================
         SECCIONES
         ===================================================== */

      .seccion-capas {

        margin:
          0 0 10px;

        border:
          1px solid #d9e2ea;

        border-radius: 9px;

        overflow: hidden;

        background: #ffffff;

      }


      .seccion-capas summary {

        cursor: pointer;

        list-style: none;

        padding:
          11px 13px;

        background:
          linear-gradient(
            90deg,
            #eef4f8,
            #f7f9fb
          );

        color: #17324d;

        font-size: 13px;

        font-weight: 700;

        border-left:
          4px solid #2f6f98;

        user-select: none;

      }


      .seccion-capas summary::-webkit-details-marker {

        display: none;

      }


      .seccion-capas summary:before {

        content: '▸';

        display: inline-block;

        width: 18px;

        color: #2f6f98;

        font-size: 14px;

      }


      .seccion-capas[open]
      summary:before {

        content: '▾';

      }


      .seccion-capas[open]
      summary {

        border-bottom:
          1px solid #d9e2ea;

        background: #e8f0f6;

      }


      .contenido-seccion {

        padding:
          10px 12px 6px;

      }


      /* =====================================================
         CONTROLES
         ===================================================== */

      .checkbox label,
      .radio label {

        color: #34495e !important;

        font-size: 12px;

        font-weight:
          600 !important;

      }


      .checkbox {

        margin-top: 6px;

        margin-bottom: 6px;

      }


      .form-control {

        border:
          1px solid #ccd8e1;

        border-radius: 7px;

        box-shadow: none;

        font-size: 12px;

      }


      .form-control:focus {

        border-color: #2f6f98;

        box-shadow:
          0 0 0 2px
          rgba(47,111,152,.12);

      }


      .shiny-input-container {

        margin-bottom: 8px;

      }


      /* =====================================================
         BOTONES
         ===================================================== */

      .btn {

        width: 100%;

        margin-bottom: 7px;

        border-radius:
          7px !important;

        font-size:
          12px !important;

        font-weight:
          600 !important;

        border:
          1px solid
          #cbd8e2 !important;

        background:
          #f7f9fb !important;

        color:
          #24435d !important;

        transition:
          all .15s ease;

      }


      .btn:hover {

        background:
          #e7f0f6 !important;

        border-color:
          #8eafc4 !important;

        transform:
          translateY(-1px);

      }


      .btn-primary {

        background:
          #2f6f98 !important;

        border-color:
          #2f6f98 !important;

        color:
          #ffffff !important;

      }


      /* =====================================================
         ESTADO
         ===================================================== */

      .estado-capas {

        background:
          #f1f5f8;

        border:
          1px solid #d7e1e8;

        border-radius: 8px;

        padding:
          10px 11px;

        margin-bottom: 12px;

        font-size: 12px;

        color: #536575;

      }


      .estado-numero {

        color: #1f587c;

        font-size: 19px;

        font-weight: 700;

      }


      /* =====================================================
         BÚSQUEDA
         ===================================================== */

      .bloque-busqueda {

        padding: 10px;

        background: #f6f8fa;

        border:
          1px solid #dce5eb;

        border-radius: 8px;

        margin-bottom: 11px;

      }


      /* =====================================================
         FICHA
         ===================================================== */

      .ficha-capa {

        background: #ffffff;

        border:
          1px solid #dce5eb;

        border-radius: 9px;

        overflow: hidden;

        margin-bottom: 12px;

      }


      .nombre-capa {

        font-size: 14px;

        font-weight: 700;

        color: #17324d;

        background: #eef4f8;

        padding: 11px 12px;

        border-left:
          4px solid #2f6f98;

        border-bottom:
          1px solid #d9e2ea;

      }


      .tabla-atributos {

        width: 100%;

        border-collapse:
          collapse;

        font-size: 11px;

      }


      .tabla-atributos td {

        border-bottom:
          1px solid #e5ebef;

        padding: 8px 7px;

        vertical-align: top;

        word-break:
          break-word;

      }


      .tabla-atributos tr:last-child td {

        border-bottom: 0;

      }


      .campo-atributo {

        width: 43%;

        font-weight: 700;

        color: #40596c;

      }


      /* =====================================================
         LEYENDA
         ===================================================== */

      .leyenda {

        margin-top: 9px;

        padding: 10px;

        background: #f8fafb;

        border:
          1px solid #dce5eb;

        border-radius: 8px;

      }


      .leyenda-titulo {

        font-size: 11px;

        font-weight: 700;

        color: #40596c;

        text-transform:
          uppercase;

        letter-spacing: .6px;

        margin-bottom: 8px;

      }


      .leyenda-elemento {

        display: flex;

        align-items: center;

        margin-bottom: 6px;

        font-size: 11px;

        color: #40596c;

        font-weight: 600;

      }


      .leyenda-color {

        width: 18px;

        height: 18px;

        margin-right: 8px;

        border:
          2px solid #333333;

        border-radius: 4px;

        flex-shrink: 0;

      }


      /* =====================================================
         INFORMACIÓN
         ===================================================== */

      .info-atlas {

        background:
          #f6f8fa;

        padding: 11px;

        border-radius: 8px;

        margin-top: 8px;

        border:
          1px solid #dce5eb;

        font-size: 11px;

        line-height: 1.8;

        color: #526575;

      }


      .info-atlas strong {

        color: #294b63;

      }


      .ayuda-clic {

        background:
          #edf5fa;

        border:
          1px solid #cfe0eb;

        border-radius: 8px;

        padding: 11px;

        color: #486274;

        font-size: 11px;

        line-height: 1.55;

      }


      .resultado-busqueda {

        background:
          #edf5fa;

        border:
          1px solid #cfe0eb;

        border-radius: 8px;

        padding: 10px;

        margin-top: 8px;

        font-size: 11px;

        color: #40596c;

      }


      /* =====================================================
         RESPONSIVE
         ===================================================== */

      @media(max-width: 1000px) {

        .panel-izquierdo {
          width: 310px;
        }

        .panel-derecho {
          width: 300px;
        }

        .badge-atlas {
          display: none;
        }

      }


      @media(max-width: 760px) {

        .encabezado {

          height: 66px;

          padding:
            10px 14px;

        }


        .titulo {

          font-size: 17px;

        }


        .subtitulo {

          font-size: 10px;

        }


        #mapa {

          top: 66px !important;

          height:
            calc(100vh - 66px) !important;

        }


        .panel-izquierdo,
        .panel-derecho {

          top: 76px;

          max-height:
            calc(100vh - 88px);

          width: 245px;

          padding: 11px;

        }


        .panel-izquierdo {

          left: 6px;

        }


        .panel-derecho {

          right: 6px;

        }

      }

      ")
    )
  ),
  
  
  # ==========================================================
  # ENCABEZADO
  # ==========================================================
  
  div(
    
    class = "encabezado",
    
    div(
      class = "titulo",
      "ATLAS DE RIESGO DEL ESTADO DE AGUASCALIENTES"
    ),
    
    div(
      class = "subtitulo",
      "Sistema de información geográfica y visor cartográfico interactivo"
    ),
    
    div(
      class = "badge-atlas",
      "VISOR CARTOGRÁFICO • V5.3"
    )
    
  ),
  
  
  # ==========================================================
  # MAPA
  # ==========================================================
  
  leafletOutput(
    "mapa",
    width = "100%",
    height = "100vh"
  ),
  
  
  # ==========================================================
  # PANEL IZQUIERDO
  # ==========================================================
  
  div(
    
    class = "panel-izquierdo",
    
    div(
      class = "titulo-panel",
      HTML(
        "<i class='fa fa-map'></i>
         CAPAS Y CONTROLES DEL ATLAS"
      )
    ),
    
    
    uiOutput(
      "estado_capas"
    ),
    
    
    # ========================================================
    # PELIGROS
    # ========================================================
    
    tags$details(
      
      class = "seccion-capas",
      
      open = "open",
      
      tags$summary(
        "PELIGROS"
      ),
      
      div(
        
        class = "contenido-seccion",
        
        checkboxGroupInput(
          
          "capas",
          
          label = NULL,
          
          choices = c(
            
            "Incendios 2019" =
              "incendios_2019",
            
            "Incendios 2020" =
              "incendios_2020",
            
            "Incendios 2021" =
              "incendios_2021",
            
            "Incendios 2022" =
              "incendios_2022",
            
            "Incendios 2023" =
              "incendios_2023",
            
            "Inundabilidad" =
              "inundacion",
            
            "Sequía" =
              "sequia"
            
          ),
          
          selected =
            character(0)
          
        )
        
      )
      
    ),
    
    
    # ========================================================
    # VULNERABILIDAD
    # ========================================================
    
    tags$details(
      
      class = "seccion-capas",
      
      open = "open",
      
      tags$summary(
        "VULNERABILIDAD"
      ),
      
      div(
        
        class = "contenido-seccion",
        
        checkboxInput(
          
          "densidad",
          
          "Densidad de población",
          
          value = FALSE
          
        )
        
      )
      
    ),
    
    
    # ========================================================
    # MAPA BASE
    # ========================================================
    
    tags$details(
      
      class = "seccion-capas",
      
      tags$summary(
        "MAPA BASE"
      ),
      
      div(
        
        class = "contenido-seccion",
        
        radioButtons(
          
          "mapa_base",
          
          label = NULL,
          
          choices = c(
            
            "Topográfico" =
              "topo",
            
            "Satélite" =
              "satellite",
            
            "Calles" =
              "streets"
            
          ),
          
          selected =
            "topo"
          
        )
        
      )
      
    ),
    
    
    # ========================================================
    # HERRAMIENTAS
    # ========================================================
    
    tags$details(
      
      class = "seccion-capas",
      
      tags$summary(
        "HERRAMIENTAS"
      ),
      
      div(
        
        class = "contenido-seccion",
        
        actionButton(
          
          "centrar",
          
          "Centrar mapa",
          
          icon =
            icon("crosshairs"),
          
          class =
            "btn btn-default"
          
        ),
        
        actionButton(
          
          "limpiar",
          
          "Limpiar información",
          
          icon =
            icon("eraser"),
          
          class =
            "btn btn-default"
          
        ),
        
        actionButton(
          
          "pantalla_completa",
          
          "Pantalla completa",
          
          icon =
            icon("expand"),
          
          class =
            "btn btn-default"
          
        )
        
      )
      
    ),
    
    
    # ========================================================
    # TRANSPARENCIA
    # ========================================================
    
    tags$details(
      
      class = "seccion-capas",
      
      tags$summary(
        "TRANSPARENCIA"
      ),
      
      div(
        
        class = "contenido-seccion",
        
        sliderInput(
          
          "opacidad",
          
          "Opacidad:",
          
          min = 0,
          
          max = 1,
          
          value = 0.60,
          
          step = 0.05,
          
          width = "100%"
          
        )
        
      )
      
    ),
    
    
    # ========================================================
    # LEYENDA
    # ========================================================
    
    tags$details(
      
      class = "seccion-capas",
      
      tags$summary(
        "LEYENDA"
      ),
      
      div(
        
        class = "contenido-seccion",
        
        uiOutput(
          "leyenda"
        )
        
      )
      
    ),
    
    
    # ========================================================
    # INFORMACIÓN DEL ATLAS
    # ========================================================
    
    div(
      
      class = "titulo-panel",
      
      HTML(
        "<i class='fa fa-info-circle'></i>
         INFORMACIÓN DEL ATLAS"
      )
      
    ),
    
    div(
      
      class = "info-atlas",
      
      strong("Estado:"),
      " Aguascalientes",
      br(),
      
      strong("Sistema:"),
      " WGS 84 / EPSG:4326",
      br(),
      
      strong("Tipo:"),
      " Atlas de Riesgo",
      br(),
      
      strong("Versión:"),
      " 5.3",
      br(),
      
      strong("Capas disponibles:"),
      " 8",
      br(),
      
      strong("Plataforma:"),
      " Posit Connect Cloud"
      
    )
    
  ),
  
  
  # ==========================================================
  # PANEL DERECHO
  # ==========================================================
  
  div(
    
    class = "panel-derecho",
    
    div(
      
      class = "titulo-panel",
      
      HTML(
        "<i class='fa fa-database'></i>
         INFORMACIÓN DE LA CAPA"
      )
      
    ),
    
    div(
      
      class = "ayuda-clic",
      
      HTML(
        "<strong>Consulta cartográfica</strong><br>
         Active una capa en el panel izquierdo y haga clic
         sobre cualquier elemento del mapa para consultar
         sus atributos."
      )
      
    ),
    
    br(),
    
    uiOutput(
      "ficha"
    ),
    
    
    # ========================================================
    # BÚSQUEDA
    # ========================================================
    
    tags$details(
      
      class = "seccion-capas",
      
      tags$summary(
        "BÚSQUEDA DE ATRIBUTOS"
      ),
      
      div(
        
        class = "contenido-seccion",
        
        textInput(
          
          "buscar",
          
          "Buscar atributo:",
          
          value = "",
          
          placeholder =
            "Ej. municipio, nombre..."
          
        ),
        
        actionButton(
          
          "ejecutar_busqueda",
          
          "Buscar",
          
          icon =
            icon("search"),
          
          class =
            "btn btn-default"
          
        ),
        
        uiOutput(
          "resultado_busqueda"
        )
        
      )
      
    )
    
  )
  
)


# ============================================================
# 12. SERVER
# ============================================================

server <- function(
    input,
    output,
    session
) {
  
  
  # ==========================================================
  # 1. MAPA INICIAL
  # ==========================================================
  
  output$mapa <- renderLeaflet({
    
    leaflet(
      options = leafletOptions(
        preferCanvas = TRUE,
        zoomControl = TRUE
      )
    ) %>%
      
      addProviderTiles(
        providers$Esri.WorldTopoMap,
        group = "Topográfico"
      ) %>%
      
      addProviderTiles(
        providers$Esri.WorldImagery,
        group = "Satélite"
      ) %>%
      
      addProviderTiles(
        providers$OpenStreetMap,
        group = "Calles"
      ) %>%
      
      setView(
        lng = CENTRO_LNG,
        lat = CENTRO_LAT,
        zoom = ZOOM_INICIAL
      ) %>%
      
      addScaleBar(
        position = "bottomleft"
      ) %>%
      
      addMeasure(
        position = "bottomleft",
        primaryLengthUnit = "meters",
        primaryAreaUnit = "hectares",
        activeColor = "#2f6f98",
        completedColor = "#17324d"
      ) %>%
      
      addLayersControl(
        
        baseGroups = c(
          "Topográfico",
          "Satélite",
          "Calles"
        ),
        
        options =
          layersControlOptions(
            collapsed = TRUE
          )
        
      ) %>%
      
      hideGroup(
        "Satélite"
      ) %>%
      
      hideGroup(
        "Calles"
      )
    
  })
  
  
  # ==========================================================
  # 2. FUNCIÓN INTERNA PARA DIBUJAR CAPAS
  # ==========================================================
  
  dibujar_capas <- function(proxy, seleccionadas, opacidad) {
    
    if (length(seleccionadas) == 0) {
      
      return(invisible(NULL))
      
    }
    
    
    for (id in seleccionadas) {
      
      if (!id %in% names(capas)) {
        
        next
        
      }
      
      
      config <- capas[[id]]
      
      datos <- config$datos
      
      
      if (is.null(datos)) {
        
        next
        
      }
      
      
      if (nrow(datos) == 0) {
        
        next
        
      }
      
      
      ids <- paste0(
        id,
        "_",
        seq_len(
          nrow(datos)
        )
      )
      
      
      proxy %>%
        
        addPolygons(
          
          data = datos,
          
          group =
            config$nombre,
          
          layerId =
            ids,
          
          fillColor =
            config$color,
          
          fillOpacity =
            opacidad,
          
          color =
            config$borde,
          
          opacity =
            opacidad,
          
          weight = 1,
          
          smoothFactor = 0.5,
          
          highlightOptions =
            highlightOptions(
              
              weight = 3,
              
              color = "#000000",
              
              bringToFront = TRUE
              
            )
          
        )
      
    }
    
    invisible(NULL)
    
  }
  
  
  # ==========================================================
  # 3. ACTIVAR / DESACTIVAR CAPAS
  # ==========================================================
  
  observeEvent(
    
    list(
      input$capas,
      input$densidad
    ),
    
    {
      
      proxy <- leafletProxy(
        "mapa"
      )
      
      
      # ------------------------------------------------------
      # ELIMINAR SOLO LAS CAPAS DEL ATLAS
      # ------------------------------------------------------
      
      for (id in names(capas)) {
        
        proxy %>%
          
          clearGroup(
            capas[[id]]$nombre
          )
        
      }
      
      
      # ------------------------------------------------------
      # OBTENER SELECCIÓN
      # ------------------------------------------------------
      
      seleccionadas <-
        obtener_capas_seleccionadas(
          input
        )
      
      
      # ------------------------------------------------------
      # DIBUJAR
      # ------------------------------------------------------
      
      dibujar_capas(
        
        proxy,
        
        seleccionadas,
        
        input$opacidad
        
      )
      
    },
    
    ignoreInit = FALSE
    
  )
  
  
  # ==========================================================
  # 4. ACTUALIZAR OPACIDAD SIN RECARGAR LAS GEOMETRÍAS
  # ==========================================================
  
  observeEvent(
    
    input$opacidad,
    
    {
      
      session$sendCustomMessage(
        
        "actualizar_opacidad",
        
        list(
          valor = input$opacidad
        )
        
      )
      
    },
    
    ignoreInit = TRUE
    
  )
  
  
  # ==========================================================
  # 5. MAPA BASE
  # ==========================================================
  
  observeEvent(
    
    input$mapa_base,
    
    {
      
      proxy <-
        leafletProxy("mapa")
      
      
      switch(
        
        input$mapa_base,
        
        "topo" = {
          
          proxy %>%
            
            showGroup("Topográfico") %>%
            
            hideGroup("Satélite") %>%
            
            hideGroup("Calles")
          
        },
        
        "satellite" = {
          
          proxy %>%
            
            hideGroup("Topográfico") %>%
            
            showGroup("Satélite") %>%
            
            hideGroup("Calles")
          
        },
        
        "streets" = {
          
          proxy %>%
            
            hideGroup("Topográfico") %>%
            
            hideGroup("Satélite") %>%
            
            showGroup("Calles")
          
        }
        
      )
      
    },
    
    ignoreInit = TRUE
    
  )
  
  
  # ==========================================================
  # 6. ESTADO DE CAPAS
  # ==========================================================
  
  output$estado_capas <- renderUI({
    
    seleccionadas <-
      obtener_capas_seleccionadas(
        input
      )
    
    
    numero <-
      length(seleccionadas)
    
    
    nombres <- character(0)
    
    
    if (numero > 0) {
      
      nombres <- vapply(
        
        seleccionadas,
        
        function(id) {
          
          capas[[id]]$nombre
          
        },
        
        character(1)
        
      )
      
    }
    
    
    div(
      
      class =
        "estado-capas",
      
      strong(
        "Capas activas: "
      ),
      
      span(
        
        class =
          "estado-numero",
        
        numero
        
      ),
      
      br(),
      
      if (numero == 0) {
        
        "No hay capas seleccionadas."
        
      } else {
        
        paste(
          nombres,
          collapse = " • "
        )
        
      }
      
    )
    
  })
  
  
  # ==========================================================
  # 7. LEYENDA
  # ==========================================================
  
  output$leyenda <- renderUI({
    
    seleccionadas <-
      obtener_capas_seleccionadas(
        input
      )
    
    
    if (length(seleccionadas) == 0) {
      
      return(
        
        div(
          
          class =
            "leyenda",
          
          div(
            
            style =
              "font-size:12px;color:#555555;",
            
            "Active una capa para mostrar su simbología."
            
          )
          
        )
        
      )
      
    }
    
    
    elementos <- lapply(
      
      seleccionadas,
      
      function(id) {
        
        config <- capas[[id]]
        
        
        div(
          
          class =
            "leyenda-elemento",
          
          div(
            
            class =
              "leyenda-color",
            
            style = paste0(
              
              "background-color:",
              config$color,
              ";",
              
              "border-color:",
              config$borde,
              ";"
              
            )
            
          ),
          
          config$nombre
          
        )
        
      }
      
    )
    
    
    div(
      
      class =
        "leyenda",
      
      div(
        
        class =
          "leyenda-titulo",
        
        "Capas activas"
        
      ),
      
      elementos
      
    )
    
  })
  
  
  # ==========================================================
  # 8. CLIC SOBRE GEOMETRÍA
  # ==========================================================
  
  observeEvent(
    
    input$mapa_shape_click,
    
    {
      
      click <-
        input$mapa_shape_click
      
      
      if (
        is.null(click) ||
        is.null(click$id)
      ) {
        
        return()
        
      }
      
      
      id_click <-
        as.character(
          click$id
        )
      
      
      capa_encontrada <- NULL
      
      
      for (
        nombre_id in names(capas)
      ) {
        
        patron <- paste0(
          "^",
          nombre_id,
          "_"
        )
        
        
        if (
          grepl(
            patron,
            id_click
          )
        ) {
          
          capa_encontrada <-
            nombre_id
          
          break
          
        }
        
      }
      
      
      if (
        is.null(capa_encontrada)
      ) {
        
        return()
        
      }
      
      
      config <-
        capas[[capa_encontrada]]
      
      
      datos <-
        config$datos
      
      
      if (is.null(datos)) {
        
        return()
        
      }
      
      
      indice <- suppressWarnings(
        
        as.numeric(
          
          sub(
            ".*_",
            "",
            id_click
          )
          
        )
        
      )
      
      
      if (
        
        is.na(indice) ||
        
        indice < 1 ||
        
        indice > nrow(datos)
        
      ) {
        
        return()
        
      }
      
      
      informacion <-
        crear_tabla_atributos(
          
          datos[
            indice,
            ,
            drop = FALSE
          ]
          
        )
      
      
      output$ficha <-
        renderUI({
          
          HTML(
            
            paste0(
              
              "<div class='ficha-capa'>",
              
              "<div class='nombre-capa'>",
              
              htmlEscape(
                config$nombre
              ),
              
              "</div>",
              
              informacion,
              
              "</div>"
              
            )
            
          )
          
        })
      
    }
    
  )
  
  
  # ==========================================================
  # 9. FICHA INICIAL
  # ==========================================================
  
  output$ficha <- renderUI({
    
    div(
      
      p(
        strong(
          "Ningún elemento seleccionado"
        )
      ),
      
      p(
        "Active una capa y haga clic sobre una geometría para consultar sus atributos."
      )
      
    )
    
  })
  
  
  # ==========================================================
  # 10. LIMPIAR INFORMACIÓN
  # ==========================================================
  
  observeEvent(
    
    input$limpiar,
    
    {
      
      output$ficha <- renderUI({
        
        div(
          
          p(
            strong(
              "Ningún elemento seleccionado"
            )
          ),
          
          p(
            "Active una capa y haga clic sobre una geometría."
          )
          
        )
        
      })
      
      
      output$resultado_busqueda <- renderUI({
        NULL
      })
      
      
      updateTextInput(
        session,
        "buscar",
        value = ""
      )
      
    }
    
  )
  
  
  # ==========================================================
  # 11. CENTRAR MAPA
  # ==========================================================
  
  observeEvent(
    
    input$centrar,
    
    {
      
      leafletProxy(
        "mapa"
      ) %>%
        
        setView(
          
          lng =
            CENTRO_LNG,
          
          lat =
            CENTRO_LAT,
          
          zoom =
            ZOOM_INICIAL
          
        )
      
    }
    
  )
  
  
  # ==========================================================
  # 12. PANTALLA COMPLETA
  # ==========================================================
  
  observeEvent(
    
    input$pantalla_completa,
    
    {
      
      session$sendCustomMessage(
        
        "activar_pantalla_completa",
        
        list(
          activo = TRUE
        )
        
      )
      
    }
    
  )
  
  
  # ==========================================================
  # 13. BÚSQUEDA DE ATRIBUTOS
  # ==========================================================
  
  observeEvent(
    
    input$ejecutar_busqueda,
    
    {
      
      termino <-
        trimws(
          input$buscar
        )
      
      
      if (termino == "") {
        
        showNotification(
          
          "Escribe un término para buscar.",
          
          type = "warning",
          
          duration = 4
          
        )
        
        return()
        
      }
      
      
      seleccionadas <-
        obtener_capas_seleccionadas(
          input
        )
      
      
      if (
        length(seleccionadas) == 0
      ) {
        
        showNotification(
          
          "Primero activa una capa.",
          
          type = "warning",
          
          duration = 4
          
        )
        
        return()
        
      }
      
      
      resultados <- list()
      
      
      encontrados <- 0
      
      
      # ------------------------------------------------------
      # BUSCAR EN CADA CAPA
      # ------------------------------------------------------
      
      for (id in seleccionadas) {
        
        datos <-
          capas[[id]]$datos
        
        
        if (
          is.null(datos) ||
          nrow(datos) == 0
        ) {
          
          next
          
        }
        
        
        sf_col <-
          attr(
            datos,
            "sf_column"
          )
        
        
        columnas <-
          setdiff(
            names(datos),
            sf_col
          )
        
        
        if (
          length(columnas) == 0
        ) {
          
          next
          
        }
        
        
        # ----------------------------------------------------
        # Convertir atributos a texto de manera segura
        # ----------------------------------------------------
        
        texto <- vapply(
          
          seq_len(nrow(datos)),
          
          function(i) {
            
            valores <- vapply(
              
              columnas,
              
              function(campo) {
                
                valor <-
                  datos[[campo]][i]
                
                if (
                  length(valor) == 0 ||
                  is.na(valor)
                ) {
                  
                  return("")
                  
                }
                
                as.character(valor)
                
              },
              
              character(1)
              
            )
            
            paste(
              valores,
              collapse = " "
            )
            
          },
          
          character(1)
          
        )
        
        
        coincide <-
          grepl(
            termino,
            texto,
            ignore.case = TRUE,
            fixed = TRUE
          )
        
        
        indices <-
          which(coincide)
        
        
        if (length(indices) > 0) {
          
          encontrados <-
            encontrados +
            length(indices)
          
          
          resultados[[id]] <- list(
            
            nombre =
              capas[[id]]$nombre,
            
            indices =
              indices
            
          )
          
        }
        
      }
      
      
      # ======================================================
      # RESULTADO
      # ======================================================
      
      if (encontrados == 0) {
        
        output$resultado_busqueda <-
          renderUI({
            
            div(
              
              class =
                "resultado-busqueda",
              
              strong(
                "Sin resultados"
              ),
              
              br(),
              
              paste0(
                "No se encontraron elementos que coincidan con '",
                termino,
                "'."
              )
              
            )
            
          })
        
        
        showNotification(
          
          paste0(
            "No se encontraron elementos para: ",
            termino
          ),
          
          type = "warning",
          
          duration = 4
          
        )
        
        return()
        
      }
      
      
      # ------------------------------------------------------
      # Construir resumen
      # ------------------------------------------------------
      
      bloques <- lapply(
        
        names(resultados),
        
        function(id) {
          
          item <-
            resultados[[id]]
          
          
          cantidad <-
            length(
              item$indices
            )
          
          
          paste0(
            
            "<div style='margin-bottom:6px;'>",
            
            "<strong>",
            htmlEscape(
              item$nombre
            ),
            "</strong>: ",
            
            cantidad,
            
            ifelse(
              cantidad == 1,
              " coincidencia",
              " coincidencias"
            ),
            
            "</div>"
            
          )
          
        }
        
      )
      
      
      output$resultado_busqueda <-
        renderUI({
          
          HTML(
            
            paste0(
              
              "<div class='resultado-busqueda'>",
              
              "<strong>Resultados de búsqueda</strong><br>",
              
              "Término: <strong>",
              htmlEscape(termino),
              "</strong><br><br>",
              
              paste(
                unlist(bloques),
                collapse = ""
              ),
              
              "<strong>Total: ",
              encontrados,
              "</strong>",
              
              "</div>"
              
            )
            
          )
          
        })
      
      
      showNotification(
        
        paste(
          "Elementos encontrados:",
          encontrados
        ),
        
        type = "message",
        
        duration = 4
        
      )
      
    }
    
  )
  
}


# ============================================================
# 13. EJECUTAR APLICACIÓN
# ============================================================

cat("\n")
cat("============================================================\n")
cat(" VISOR CARTOGRÁFICO 5.3 LISTO\n")
cat("============================================================\n")
cat(" Capas configuradas:", length(capas), "\n")
cat(" CRS del mapa: EPSG:4326\n")
cat(" Centro:", CENTRO_LNG, CENTRO_LAT, "\n")
cat("============================================================\n\n")


shinyApp(
  
  ui = ui,
  
  server = server
  
)